# Cabinet Medical

## Informations
- Police au choix
- Couleur de fond : gray
- Couleur des liens au survol : orangered